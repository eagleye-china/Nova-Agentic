"""NovaCard QML 演示程序入口。"""

from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import QObject, QUrl
from PySide6.QtGui import QGuiApplication
from PySide6.QtQml import QQmlApplicationEngine


class DemoBridge(QObject):
    """演示用 Python 侧逻辑桥接对象（当前无业务逻辑）。"""

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)


def main() -> int:
    """启动 QML 演示窗口。"""
    app: QGuiApplication = QGuiApplication(sys.argv)

    engine: QQmlApplicationEngine = QQmlApplicationEngine()
    qml_dir: Path = Path(__file__).resolve().parent
    engine.addImportPath(str(qml_dir))

    demo_url: QUrl = QUrl.fromLocalFile(str(qml_dir / "demo_nova_card.qml"))
    engine.load(demo_url)

    if not engine.rootObjects():
        return 1

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
