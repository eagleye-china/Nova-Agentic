"""NovaCard 演示程序入口。

Python 端仅负责引擎初始化与 QML 加载，UI 全部由 QML 声明式描述。
"""

from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtGui import QGuiApplication
from PySide6.QtQml import QQmlApplicationEngine


def main() -> int:
    """启动 NovaCard 演示程序。"""
    app = QGuiApplication(sys.argv)

    engine = QQmlApplicationEngine()
    qml_file: Path = Path(__file__).resolve().parent / "CardDemo.qml"
    engine.load(str(qml_file))

    if not engine.rootObjects():
        return 1

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
