from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import QObject, QUrl, Signal, Slot
from PySide6.QtGui import QGuiApplication
from PySide6.QtQml import QQmlApplicationEngine
from PySide6.QtQuick import QQuickWindow, QSGRendererInterface


class ButtonDemoBridge(QObject):
    """Python 侧逻辑桥：只负责逻辑，UI 全部在 QML 中声明。"""

    clickedCountChanged = Signal(int)

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._clicked_count: int = 0

    @Slot()
    def onPrimaryClicked(self) -> None:
        self._clicked_count += 1
        print(f"[primary] clicked, total={self._clicked_count}")
        self.clickedCountChanged.emit(self._clicked_count)

    @Slot()
    def onSecondaryClicked(self) -> None:
        print("[secondary] clicked")

    @Slot()
    def onDangerClicked(self) -> None:
        print("[danger] clicked")


def main() -> None:
    QQuickWindow.setGraphicsApi(QSGRendererInterface.GraphicsApi.Direct3D11)

    app: QGuiApplication = QGuiApplication(sys.argv)

    engine: QQmlApplicationEngine = QQmlApplicationEngine()

    qml_dir: Path = Path(__file__).resolve().parent
    engine.addImportPath(str(qml_dir))

    bridge: ButtonDemoBridge = ButtonDemoBridge()
    engine.rootContext().setContextProperty("bridge", bridge)

    demo_qml: Path = qml_dir / "DemoButton.qml"
    engine.load(QUrl.fromLocalFile(str(demo_qml)))

    if not engine.rootObjects():
        sys.exit(-1)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
