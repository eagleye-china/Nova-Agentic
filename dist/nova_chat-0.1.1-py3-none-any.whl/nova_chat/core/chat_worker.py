# src/ai_chat/core/chat_worker.py
import datetime  # ✅ 引入时间模块
import json
import os
import shutil

from PySide6.QtCore import QThread, Signal
from openai import OpenAI

# =====================================================================
# 📜 智能体内置《架构宪法》（带动态时间戳注入）
# =====================================================================
SYSTEM_PROMPT_TEMPLATE = """
你是 PySide-Nova 框架的首席 AI 架构师。PySide-Nova 是一个基于 PySide6 + QML 的企业级 UI 组件库，专为工业 HMI、大屏和数据密集型应用设计。

在协助我开发或修改任何代码时，必须无条件遵守以下《架构宪法》：
1. 【纯 QML 声明式 UI】：界面和动画必须完全使用 QML 原生语法编写。
2. 【禁止分组属性动画】：严禁使用 `Behavior on border.color` 等分组属性，必须使用 `states` + `transitions`。
3. 【属性契约强制一致】：属性名必须严格对齐 pyside-quasar。
4. 【高 DPI 与响应式】：布局优先使用 `anchors` 和 `Layout`，尺寸使用 `dp` 或 `Units.px()`。
5. 【代码溯源规范】：你生成的每一个代码文件（QML 或 Python），必须在文件头部添加一段注释。请严格使用以下格式：
   /**
    * @created {current_time}
    * @author  eagleye-china & 小诺 (AI Architect)
    * @module  Nova 1.0
    */
6. 【⚠️ 最高红线指令：言出法随】：只要你在聊天框里输出了任何总结文字（如“已完成”、“本次新增”、“全部覆盖”），就意味着任务立即结束！绝对禁止在输出总结后，再次调用工具去读写文件！

当前系统时间已校准为：{current_time}
"""


class ChatWorker(QThread):
    chunk_received = Signal(str)
    action_log = Signal(str)
    finished_signal = Signal()
    error_signal = Signal(str)

    def __init__(self, api_key, base_url, model, messages, project_root):
        super().__init__()
        self.api_key = api_key
        self.base_url = base_url
        self.model = model
        self.messages = messages
        self.project_root = project_root
        self._is_running = True

        # 只保留必要工具，删除了 run_ruff 以防死循环
        self.tools = [
            {
                "type": "function",
                "function": {
                    "name": "read_file",
                    "description": "读取项目中的文件内容。在修改代码或参考现有组件风格时非常有用。",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "file_path": {"type": "string", "description": "相对路径"}
                        },
                        "required": ["file_path"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "write_multiple_files",
                    "description": "将生成的代码同时写入到多个指定的项目文件中。",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "files": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "file_path": {"type": "string"},
                                        "code": {"type": "string"}
                                    },
                                    "required": ["file_path", "code"]
                                }
                            }
                        },
                        "required": ["files"]
                    }
                }
            }
        ]

    def stop(self):
        self._is_running = False

    def _read_file(self, file_path):
        full_path = os.path.join(self.project_root, file_path)
        if not os.path.exists(full_path):
            return f"错误: 文件 {file_path} 不存在。"
        try:
            with open(full_path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            return f"读取失败: {str(e)}"

    def _write_files(self, files_list):
        results = []
        for item in files_list:
            file_path = item.get("file_path", "")
            code = item.get("code", "")
            if not file_path or not code:
                continue

            full_path = os.path.join(self.project_root, file_path)
            os.makedirs(os.path.dirname(full_path), exist_ok=True)

            # 自动备份机制
            if os.path.exists(full_path):
                bak_path = full_path + ".bak"
                shutil.copy2(full_path, bak_path)
                self.action_log.emit(f"⚠️ 检测到旧文件，已备份至 {file_path}.bak")

            with open(full_path, "w", encoding="utf-8") as f:
                f.write(code)
            results.append(file_path)

        return f"成功批量写入 {len(results)} 个文件: {', '.join(results)}"

    def run(self):
        try:
            client = OpenAI(api_key=self.api_key, base_url=self.base_url)

            # ✅ 核心：获取精确到秒的系统时间，并注入宪法
            now = datetime.datetime.now()
            current_time_str = now.strftime("%Y-%m-%d %H:%M:%S")
            system_prompt = SYSTEM_PROMPT_TEMPLATE.replace("{current_time}", current_time_str)

            final_messages = [{"role": "system", "content": system_prompt}] + self.messages

            # 写文件次数熔断器
            write_count = 0

            while self._is_running:
                response = client.chat.completions.create(
                    model=self.model,
                    messages=final_messages,
                    tools=self.tools,
                    tool_choice="auto"
                )

                message = response.choices[0].message

                if message.tool_calls:
                    assistant_msg = {"role": "assistant", "content": message.content or ""}
                    assistant_msg["tool_calls"] = [
                        {"id": tc.id, "type": tc.type,
                         "function": {"name": tc.function.name, "arguments": tc.function.arguments}}
                        for tc in message.tool_calls
                    ]
                    self.messages.append(assistant_msg)
                    final_messages.append(assistant_msg)

                    for tool_call in message.tool_calls:
                        # 🚨 拦截：如果 AI 试图第 3 次写文件，直接掐断！
                        if tool_call.function.name == "write_multiple_files":
                            write_count += 1
                            if write_count > 2:
                                self.action_log.emit("⚠️ AI 陷入修改狂魔模式，已强行终止写入！")
                                self.chunk_received.emit(
                                    "\n\n**【系统强制介入】** AI 陷入了反复改代码的死循环。已强制中断。请检查当前生成的代码是否符合预期！")
                                self.finished_signal.emit()
                                return

                        tool_content = "未执行"
                        try:
                            args = json.loads(tool_call.function.arguments)

                            if tool_call.function.name == "read_file":
                                self.action_log.emit(f"📖 正在读取: {args.get('file_path')}")
                                tool_content = self._read_file(args.get("file_path", ""))

                            elif tool_call.function.name == "write_multiple_files":
                                files = args.get("files", [])
                                file_names = [f.get("file_path") for f in files]
                                self.action_log.emit(f"🛠️ 准备批量写入文件: {', '.join(file_names)}")
                                tool_content = self._write_files(files)

                        except Exception as e:
                            tool_content = f"工具执行异常: {str(e)}"

                        tool_msg = {"role": "tool", "tool_call_id": tool_call.id, "content": tool_content}
                        self.messages.append(tool_msg)
                        final_messages.append(tool_msg)
                        # ✅ 新增提示：告诉用户工具干完了，正在等 AI 思考

                    self.action_log.emit("⏳ 工具执行完毕，正在请求 AI 进行下一步思考...")
                    continue

                # 🚨 终极熔断：只要 AI 不调工具，开始输出文字总结，立刻结束战斗！
                if message.content:
                    self.chunk_received.emit(message.content)
                    self.messages.append({"role": "assistant", "content": message.content})
                    self.finished_signal.emit()
                    return

                self.finished_signal.emit()
                return

        except Exception as e:
            if self._is_running:
                self.error_signal.emit(str(e))
