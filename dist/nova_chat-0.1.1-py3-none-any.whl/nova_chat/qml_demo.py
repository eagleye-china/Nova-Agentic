from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import QUrl
from PySide6.QtGui import QGuiApplication
from PySide6.QtQml import QQmlApplicationEngine


def main() -> int:
    """加载 NovaCardDemo.qml 并启动 QML 应用。"""
    app: QGuiApplication = QGuiApplication(sys.argv)

    engine: QQmlApplicationEngine = QQmlApplicationEngine()
    qml_dir: Path = Path(__file__).resolve().parent / "qml"
    engine.addImportPath(str(qml_dir))

    qml_file: Path = qml_dir / "NovaCardDemo.qml"
    engine.load(QUrl.fromLocalFile(str(qml_file)))

    if not engine.rootObjects():
        return -1

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
